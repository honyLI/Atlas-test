Hi,

Please read `contributing guide <https://hunter.readthedocs.io/en/latest/contributing.html>`__ before sending pull requests or reporting bugs.

Thank you!
