.. Copyright (c) 2016, Ruslan Baratov
.. All rights reserved.

CMake only
----------

No other dependencies - **just CMake** and your environment/IDE (no need for
Git or Python or anything).
