.. Copyright (c) 2016, Ruslan Baratov
.. All rights reserved.

Works everywhere!
-----------------

Hunter works everywhere: CMake-GUI, Qt Creator, Visual Studio, Xcode, Cygwin,
MinGW, Jenkins, Travis etc.

.. seealso::

  * :doc:`F.A.Q.: How to use Hunter in Android Studio? </faq/android-studio>`
