.. spelling::

    ccv

.. index:: computer-vision ; ccv

.. _pkg.ccv:

ccv
===

-  `Official <https://github.com/liuliu/ccv>`__
-  `Hunterized <https://github.com/hunter-packages/ccv>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/ccv/CMakeLists.txt>`__

.. literalinclude:: /../examples/ccv/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
