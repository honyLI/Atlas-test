.. spelling::

    eabi

.. index:: android_sdk_component ; android_arm_eabi_v7a_system_image_packer

.. _pkg.android_arm_eabi_v7a_system_image_packer:

android_arm_eabi_v7a_system_image_packer
========================================

-  `Official <https://github.com/hunter-packages/android_arm_eabi_v7a_system_image_packer>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/android_arm_eabi_v7a_system_image_packer/CMakeLists.txt>`__

.. literalinclude:: /../examples/android_arm_eabi_v7a_system_image_packer/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
