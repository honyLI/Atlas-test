.. spelling::

    RedisClient

.. index::
  single: unsorted ; RedisClient

.. _pkg.RedisClient:

RedisClient
===========

-  `Official GitHub <https://github.com/nekipelov/redisclient>`__
-  `Hunterized <https://github.com/hunter-packages/redisclient>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/RedisClient/CMakeLists.txt>`__

.. literalinclude:: /../examples/RedisClient/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
