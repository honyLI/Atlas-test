.. spelling::

    jsmn

.. index::
  single: json ; jsmn

.. _pkg.jsmn:

jsmn
====

-  `Official <https://github.com/zserge/jsmn>`__
-  `Hunterized <https://github.com/cpp-pm/jsmn>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/jsmn/CMakeLists.txt>`__
-  Added by `Rahul Sheth <https://github.com/rbsheth>`__ (`pr-279 <https://github.com/cpp-pm/hunter/pull/279>`__)

.. literalinclude:: /../examples/jsmn/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
