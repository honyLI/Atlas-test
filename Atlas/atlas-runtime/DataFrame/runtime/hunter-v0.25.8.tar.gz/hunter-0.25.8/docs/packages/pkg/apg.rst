.. spelling::

    apg

.. index::
  single: unsorted ; apg

.. _pkg.apg:

apg
===

-  `Official <https://github.com/capnramses/apg>`__
-  `Hunterized <https://github.com/cpp-pm/apg>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/apg/CMakeLists.txt>`__
-  Added by `Rahul Sheth <https://github.com/rbsheth>`__ (`pr-268 <https://github.com/cpp-pm/hunter/pull/268>`__)

.. literalinclude:: /../examples/apg/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
