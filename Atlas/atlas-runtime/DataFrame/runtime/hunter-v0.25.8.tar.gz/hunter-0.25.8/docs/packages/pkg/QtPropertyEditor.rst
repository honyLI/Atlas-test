.. spelling::

    QtPropertyEditor

.. index::
  single: unsorted ; QtPropertyEditor

.. _pkg.QtPropertyEditor:

QtPropertyEditor
================

-  `Official <https://github.com/Energid/propertyeditor>`__
-  `Hunterized <https://github.com/hunter-packages/QtPropertyEditor>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/QtPropertyEditor/CMakeLists.txt>`__
-  Added by `t0p4 <https://github.com/t0p4>`__ (`pr-1670 <https://github.com/ruslo/hunter/pull/1670>`__)

.. literalinclude:: /../examples/QtPropertyEditor/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
