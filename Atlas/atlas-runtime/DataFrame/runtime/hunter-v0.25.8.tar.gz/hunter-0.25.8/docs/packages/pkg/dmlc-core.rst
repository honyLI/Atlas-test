.. spelling::

    dmlc

.. index:: unsorted ; dmlc-core

.. _pkg.dmlc-core:

dmlc-core
=========

-  `Official <https://github.com/dmlc/dmlc-core>`__
-  `Hunterized <https://github.com/hunter-packages/dmlc-core>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/dmlc-core/CMakeLists.txt>`__

.. literalinclude:: /../examples/dmlc-core/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
