.. spelling::

    Qwt

.. index::
  single: unsorted ; Qwt

.. _pkg.Qwt:

Qwt
===

-  `Official <http://qwt.sourceforge.net>`__
-  `Hunterized <https://github.com/hunter-packages/Qwt>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/Qwt/CMakeLists.txt>`__
-  Added by `t0p4 <https://github.com/t0p4>`__ (`pr-1626 <https://github.com/ruslo/hunter/pull/1626>`__)

.. literalinclude:: /../examples/Qwt/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
