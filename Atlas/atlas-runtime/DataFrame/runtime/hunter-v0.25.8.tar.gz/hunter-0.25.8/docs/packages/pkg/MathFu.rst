.. spelling::

    MathFu

.. index::
  single: math ; MathFu

.. _pkg.MathFu:

MathFu
======

-  `Official <https://github.com/google/mathfu>`__
-  `Hunterized <https://github.com/hunter-packages/mathfu>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/MathFu/CMakeLists.txt>`__
-  Added by `Rahul Sheth <https://github.com/rbsheth>`__ (`pr-1687 <https://github.com/ruslo/hunter/pull/1687>`__)

.. literalinclude:: /../examples/MathFu/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
