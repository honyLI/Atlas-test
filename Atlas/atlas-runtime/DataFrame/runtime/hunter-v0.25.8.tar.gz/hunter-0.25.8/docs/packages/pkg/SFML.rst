.. spelling::

    SFML

.. index::
  single: graphics ; SFML

.. _pkg.SFML:

SFML
====

-  `Official <https://github.com/SFML/SFML>`__
-  `Hunterized <https://github.com/cpp-pm/SFML>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/SFML/CMakeLists.txt>`__
-  Added by `drodin <https://github.com/drodin>`__ (`pr-N <https://github.com/cpp-pm/hunter/pull/N>`__)

.. literalinclude:: /../examples/SFML/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
