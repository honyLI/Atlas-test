.. spelling::

    Zug

.. index::
  single: unsorted ; Zug

.. _pkg.Zug:

Zug
===

-  `Official <https://github.com/arximboldi/zug>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/Zug/CMakeLists.txt>`__
-  Added by `Joerg-Christian Boehme <https://github.com/Bjoe>`__ (`pr-107 <https://github.com/ruslo/hunter/pull/107>`__)

.. literalinclude:: /../examples/Zug/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
