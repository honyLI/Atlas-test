.. spelling::

    android
    build
    tools
    packer

.. index:: android_sdk_component ; android_build_tools_packer

.. _pkg.android_build_tools_packer:

android_build_tools_packer
==========================

-  `Official <https://github.com/hunter-packages/android_build_tools_packer>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/android_build_tools_packer/CMakeLists.txt>`__

.. literalinclude:: /../examples/android_build_tools_packer/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
