.. spelling::

    eventpp

.. index:: messaging ; eventpp

.. _pkg.eventpp:

eventpp
=======

-  `Official <https://github.com/wqking/eventpp>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/eventpp/CMakeLists.txt>`__
-   Added by `bazfp <https://github.com/bazfp>`__

.. literalinclude:: /../examples/eventpp/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
