.. spelling::

  autotools

CMake Modules
-------------

 - :ref:`pkg.autoutils` - CMake utilities to imitate autotools functions
 - :ref:`pkg.CreateLaunchers` - CMake module to create command line and debug launchers, including MSVC ".user" file.
 - :ref:`pkg.Sugar` - CMake tools and examples
