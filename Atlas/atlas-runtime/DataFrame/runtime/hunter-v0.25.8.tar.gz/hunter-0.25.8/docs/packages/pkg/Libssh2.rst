.. spelling::

    Libssh

.. index:: networking ; Libssh2

.. _pkg.Libssh2:

Libssh2
=======

-  `Official <http://www.libssh2.org/>`__
-  `Hunterized <https://github.com/hunter-packages/libssh2>`__

.. -  `__FIXME__ Example <https://github.com/cpp-pm/hunter/blob/master/examples/__FIXME__/CMakeLists.txt>`__
.. -  Available since `__FIXME__ vX.Y.Z <https://github.com/cpp-pm/hunter/releases/tag/vX.Y.Z>`__

-  Added by `Alexander Lamaison <https://github.com/alamaison>`__
   (`pr-48 <https://github.com/ruslo/hunter/pull/48>`__)
